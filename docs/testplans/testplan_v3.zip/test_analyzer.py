import unittest
from analyzer import parse_error_logs

class TestAnalyzer(unittest.TestCase):
    def test_strict_error_matching(self):
        logs = [
            "ERROR: Alice connection reset",
            "INFO: Bob logged in",
            "INFO: ERROR_BOT started", 
            "ERROR: Alice timeout",
            "WARNING: Charlie high latency",
            "ERROR: Charlie disconnect"
        ]
        # ERROR_BOT should NOT be counted. Bob should NOT be in the result.
        expected = {"Alice": 2, "Charlie": 1}
        self.assertEqual(parse_error_logs(logs), expected)

    def test_sorting_rules(self):
        logs = [
            "ERROR: Zebra failed",
            "ERROR: Alpha failed",
            "ERROR: Alpha failed again",
            "ERROR: Bravo failed",
            "ERROR: Bravo failed too",
            "ERROR: Charlie failed"
        ]
        # Alpha: 2, Bravo: 2, Charlie: 1, Zebra: 1
        expected = {"Alpha": 2, "Bravo": 2, "Charlie": 1, "Zebra": 1}
        result = parse_error_logs(logs)
        
        # Verify dictionary key order (Python 3.7+ preserves insertion order)
        self.assertEqual(list(result.keys()), ["Alpha", "Bravo", "Charlie", "Zebra"])
        self.assertEqual(result, expected)

if __name__ == "__main__":
    unittest.main()