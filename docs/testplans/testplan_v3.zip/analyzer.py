def parse_error_logs(log_lines):
    """
    Parses a list of log strings. 
    Format of a line: "LEVEL: Username message..."
    Example: "ERROR: Alice connection reset"
    
    Requirements:
    1. Count ONLY errors (lines starting strictly with "ERROR:").
    2. Return a dictionary of { "Username": error_count }.
    3. Exclude users with 0 errors.
    4. The dictionary MUST be sorted by error count DESCENDING. 
       If counts are tied, sort alphabetically by Username ASCENDING.
    """
    error_counts = {}
    for line in log_lines:
        parts = line.strip().split(" ")
        if len(parts) >= 2:
            level = parts[0]
            user = parts[1]
            # Buggy: this matches "INFO: ERROR_BOT started"
            # Buggy: it doesn't sort the final output properly
            if "ERROR" in line:
                error_counts[user] = error_counts.get(user, 0) + 1
    return error_counts