You are an elite autonomous developer. Your goal is to FULLY complete the task below without human intervention.

IMPORTANT:
- Do not stop early. Do not explain what you would do — DO it.
- Only finish when everything works, all tests pass, and all files are generated.
- CRITICAL GUARDRAIL: Never include markdown backticks (```) inside the actual code files you write.

---

PROJECT SETUP:

There is a folder with these initial files:

1. analyzer.py (Contains a buggy implementation)
2. test_analyzer.py (Contains strict unit tests)
3. main.py (Empty)

---

TASK:

1. DEBUG THE ALGORITHM (`analyzer.py`): 
   - Run `test_analyzer.py` using bash. The tests WILL fail.
   - Fix the logic in `analyzer.py` so it properly matches strict error levels and returns a correctly sorted dictionary according to the docstring.
   - Re-run the tests until they pass.

2. IMPLEMENT CLI SCRIPT (`main.py`):
   - `main.py` MUST accept exactly two command-line arguments: an `input_dir` and an `output_file`. 
     (e.g., `python3 main.py ./my_logs ./results.json`)
   - It must scan `input_dir` and read the contents of ONLY files ending in `.log` (ignore `.txt`, `.bak`, etc.).
   - It must combine all lines from all valid `.log` files and pass them to `parse_error_logs()`.
   - It must save the resulting dictionary as strict, valid JSON to the `output_file`.

3. CREATE AN ENVIRONMENT & BASH SCRIPT (`run.sh`):
   - Create a script named `run.sh`.
   - Step 1: Run the unit tests. If tests fail, exit the script immediately with code 1.
   - Step 2: IF tests pass, use bash commands inside `run.sh` to physically create a directory named `test_logs`.
   - Step 3: Inside `test_logs`, use bash `echo` commands to create three files:
      - `system.log` containing "ERROR: Delta crash\nINFO: Echo online"
      - `app.log` containing "ERROR: Delta timeout\nERROR: Charlie lag"
      - `readme.txt` containing "ERROR: This file should be ignored"
   - Step 4: Execute `main.py` passing `test_logs` as the input directory and `final_output.json` as the output file.
   - Step 5: Make sure the script is executable.

4. EXECUTE AND VERIFY:
   - Run your `./run.sh` script.
   - If anything fails, you MUST fix it and re-run.

5. COMPLETION:
   - Once `./run.sh` runs flawlessly and `final_output.json` exists and contains the correct JSON (Delta: 2, Charlie: 1), print EXACTLY AND ONLY THIS STRING on its own line: 
   V3_STRESS_TEST_PASSED_SUCCESSFULLY

---

CONSTRAINTS:
- VERIFY BY RUNNING CODE. Do not assume your fixes worked.
- Do NOT stop if a test fails — fix it.
- Your final output must strictly be the success string, printed exactly once.
