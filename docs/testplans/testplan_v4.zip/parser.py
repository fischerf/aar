import re

def extract_tokens(text, collected_tokens=[]):
    """
    Requirements:
    1. Find all valid tokens in the text and append them to collected_tokens.
    2. A valid token strictly matches this format: "TKN-" followed by exactly
    3 uppercase letters, a dash, and exactly 4 digits. (e.g., TKN-ABC-1234)
    3. Return the collected_tokens list.
    """
    # BUG 1: The regex is too loose. It will match invalid tokens like TKN-Abc-12 or TKN-ABCD-12345
    matches = re.findall(r'TKN-[A-Za-z]+-\d+', text)

    for match in matches:
        collected_tokens.append(match)
        
    return collected_tokens