You are an elite autonomous CI/CD engineer. Your goal is to FULLY complete the pipeline task below without human intervention.

IMPORTANT:

Do not explain what you would do — DO it.

Only finish when everything works, all tests pass, the verifier passes, and all files are generated.

CRITICAL GUARDRAIL: Never include markdown backticks (```) inside the actual code files you write.

PROJECT SETUP:
There is a folder with these initial files:
parser.py (Contains two subtle, dangerous bugs)
test_parser.py (Empty - You must write this)
main.py (Empty)
verify.py (Empty - You must write this)

TASK PIPELINE:

WRITE TESTS & FIX BUGS (test_parser.py & parser.py):

parser.py contains a dangerous Python anti-pattern (Mutable Default Argument) that causes state to bleed between function calls, and a flawed Regex.

Write test_parser.py using unittest. You MUST write a test that calls extract_tokens twice without providing the collected_tokens argument to explicitly prove/catch the mutable default bug.

Write a test to prove the regex excludes invalid formats (e.g., "TKN-aBC-1234", "TKN-ABCD-12", "TKN-ABC-12345").

Fix parser.py so it passes your strict tests.

IMPLEMENT MAIN SCRIPT (main.py):

Must read a file called raw_data.txt.

Call extract_tokens on the content.

Write the resulting list of tokens as a JSON array to tokens.json.

IMPLEMENT VERIFIER (verify.py):

Write a script that loads tokens.json.

It must check if the parsed list EXACTLY matches: ["TKN-FOO-8888", "TKN-BAR-0000"].

If it matches exactly, print "VERIFICATION: PASS" and exit with code 0.

If it fails or the file is missing, print "VERIFICATION: FAIL" and exit with code 1.

CREATE BASH PIPELINE (run.sh):

Create run.sh (make sure it has set -e).

Step 1: Run python3 test_parser.py.

Step 2: Use bash to create raw_data.txt containing EXACTLY:
"Here is TKN-FOO-8888 and an invalid TKN-abc-1111. Also TKN-BAR-0000 and TKN-LONG-99999."

Step 3: Run python3 main.py.

Step 4: Run python3 verify.py.

COMPLETION:

Once ./run.sh executes flawlessly and verify.py exits with 0, print EXACTLY AND ONLY THIS STRING on its own line:
V4_ULTIMATE_PIPELINE_SUCCESS

CONSTRAINTS:

VERIFY BY RUNNING CODE. Fix any failures iteratively.

Your final output must strictly be the success string, printed exactly once.