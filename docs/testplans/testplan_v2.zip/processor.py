def process_data(items):
    # Buggy implementation: needs to filter out strings, 
    # keep only positive integers, and return them multiplied by 10.
    result = []
    for item in items:
        if item > 0:
            result.append(item * 10)
    return result
