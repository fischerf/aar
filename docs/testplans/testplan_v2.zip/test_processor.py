import unittest
from processor import process_data

class TestProcessor(unittest.TestCase):
    def test_standard_numbers(self):
        self.assertEqual(process_data([1, -2, 3]), [10, 30])

    def test_mixed_types(self):
        # Should ignore non-integers and strings
        self.assertEqual(process_data([5, "apple", -9, 2.5, 4]), [50, 40])
        
    def test_empty_and_zeros(self):
        self.assertEqual(process_data([0, "0", []]), [])

if __name__ == "__main__":
    unittest.main()
