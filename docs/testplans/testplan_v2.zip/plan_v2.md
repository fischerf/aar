You are an autonomous developer. Your goal is to FULLY complete the task below.

IMPORTANT:
- Do not stop early.
- Do not explain what you would do — DO it.
- Only finish when everything works and all requirements are satisfied.
- CRITICAL: Never include markdown backticks (```) inside the actual code files you write.

---

PROJECT SETUP:

There is a folder with these files:

1. processor.py (Contains a buggy implementation)
2. test_processor.py (Contains correct, strict tests)
3. data.txt (Contains raw input)
4. main.py (Empty)

Contents:

--- processor.py ---
def process_data(items):
    # Buggy implementation: needs to filter out strings, 
    # keep only positive integers, and return them multiplied by 10.
    result = []
    for item in items:
        if item > 0:
            result.append(item * 10)
    return result

--- test_processor.py ---
import unittest
from processor import process_data

class TestProcessor(unittest.TestCase):
    def test_standard_numbers(self):
        self.assertEqual(process_data([1, -2, 3]), [10, 30])

    def test_mixed_types(self):
        # Should ignore non-integers and strings
        self.assertEqual(process_data([5, "apple", -9, 2.5, 4]), [50, 40])
        
    def test_empty_and_zeros(self):
        self.assertEqual(process_data([0, "0", []]), [])

if __name__ == "__main__":
    unittest.main()

--- data.txt ---
15
-4
hello
8
3.14
12

---

TASK:

1. DEBUG THE LOGIC: 
   - Run `test_processor.py` using bash. The tests WILL fail.
   - Analyze the test output, fix the logic inside `processor.py` so it properly handles strings, floats, and negative numbers as required by the tests.
   - Re-run the tests until they pass with exit code 0.

2. IMPLEMENT FILE I/O in `main.py`:
   - Write code in `main.py` to read the contents of `data.txt`.
   - Parse the lines into a Python list of mixed types.
   - Pass the list to `process_data()`.
   - Write the resulting list to a new file called `output.txt` (one number per line).

3. CREATE A BASH SCRIPT (`run.sh`):
   - Create a bash script named `run.sh`.
   - The script must first run the unit tests.
   - IF AND ONLY IF the unit tests pass, the script should execute `main.py`.
   - Make sure the script is executable.

4. EXECUTE AND VERIFY:
   - Run your `./run.sh` script via bash.
   - Ensure `output.txt` is generated correctly.
   - If anything fails at any point (tests, permissions, execution), you MUST fix it and re-run.

5. COMPLETION:
   - Once `./run.sh` runs flawlessly and `output.txt` exists, print EXACTLY AND ONLY THIS STRING on its own line: 
   SUCCESS: ALL_SYSTEMS_GO

---

CONSTRAINTS:
- VERIFY BY RUNNING CODE. Do not assume your fix worked.
- Do NOT stop if a test fails — fix it.
- Your final output must strictly be the success string, printed exactly once.
