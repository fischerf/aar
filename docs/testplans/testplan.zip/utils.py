def process_numbers(nums):
    # TODO: implement
    pass
