from utils import process_numbers

def main():
    nums = [1, 2, 3, 4]
    result = process_numbers(nums)
    print(result)

if __name__ == "__main__":
    main()
